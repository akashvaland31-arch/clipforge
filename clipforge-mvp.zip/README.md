# ClipForge MVP

A deliberately small MVP for turning a long video into AI-selected vertical clips.

## What it does

1. Upload a video.
2. Store it in Supabase Storage.
3. Create a queued job.
4. Worker downloads the video.
5. OpenAI transcribes it with timestamps.
6. OpenAI selects up to 5 promising clip windows and writes title/hook/caption metadata.
7. FFmpeg renders each window into 1080x1920 MP4.
8. Rendered clips are uploaded back to Supabase Storage.

## Stack

- Next.js + React + TypeScript
- Supabase Postgres + Storage
- OpenAI API for transcription and clip selection
- FFmpeg for video processing
- Stripe Checkout for the £5 purchase
- Vercel for the web app
- Separate Node worker for long-running media jobs

Next.js is supported directly on Vercel, while long-running video work should remain in a separate worker. Supabase provides Postgres and Storage. Stripe Checkout supports one-time payments and subscriptions.

## Setup

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the SQL editor.
3. Create an OpenAI API key.
4. Create a Stripe product priced at £5 and put its Price ID in `STRIPE_PRICE_ID`.
5. Copy `.env.example` to `.env.local` and fill values.
6. Install dependencies:

   npm install

7. Install FFmpeg on the worker machine and make sure `ffmpeg` is on PATH.
8. Start the web app:

   npm run dev

9. In another terminal start the worker:

   npm run worker

## Important production upgrades

This is an MVP, not a finished SaaS. Before public launch:

- Add Supabase Auth and RLS.
- Replace server-side multipart upload with signed/direct uploads.
- Add a real job queue (Redis/BullMQ or a managed queue).
- Add a dedicated media worker with persistent temporary disk.
- Add duration/file-size limits.
- Add progress updates.
- Add signed download URLs.
- Add Stripe webhook to credit purchases.
- Add abuse/rate limiting.
- Add automatic subtitle rendering rather than the current clean 9:16 crop/pad.
- Add face-aware/reframing logic.
- Add project history and delete controls.
- Add Terms, Privacy Policy and copyright/acceptable-use rules.
- Never expose the Supabase service-role key or OpenAI key to the browser.
