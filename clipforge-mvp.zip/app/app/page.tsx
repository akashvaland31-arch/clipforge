use client';

import { useState } from "react";

export default function Dashboard() {
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function submit() {
    if (!file) return;
    setBusy(true);
    setMessage("Uploading...");
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (!res.ok) {
      setMessage(data.error || "Upload failed");
      setBusy(false);
      return;
    }
    setMessage(`Project ${data.jobId} created. The worker will process it.`);
    setBusy(false);
  }

  return (
    <main className="shell">
      <nav className="nav"><div className="logo">ClipForge</div><a href="/">Home</a></nav>
      <div className="card">
        <h1 style={{fontSize:48}}>New project</h1>
        <p className="sub">Upload a video file. MVP limit: keep test files reasonably small.</p>
        <div className="upload">
          <input type="file" accept="video/*" onChange={e => setFile(e.target.files?.[0] || null)} />
          <button className="btn" disabled={!file || busy} onClick={submit}>
            {busy ? "Working..." : "Generate clips"}
          </button>
          {message && <div className={message.includes("failed") ? "error" : "success"}>{message}</div>}
        </div>
        <p className="notice">
          Production version should use direct-to-object-storage uploads and a queue/worker for long videos.
        </p>
      </div>
    </main>
  );
}