create table if not exists public.jobs (
  id uuid primary key,
  created_at timestamptz not null default now(),
  source_path text not null,
  status text not null default 'queued',
  transcript jsonb,
  suggestions jsonb,
  output_paths jsonb,
  credits_used integer not null default 1,
  error text
);

create index if not exists jobs_status_idx on public.jobs(status);

insert into storage.buckets (id, name, public)
values ('videos', 'videos', false)
on conflict (id) do nothing;

-- MVP: worker uses the service-role key. For a public production app,
-- add Supabase Auth and RLS policies so users can only see their own jobs.
