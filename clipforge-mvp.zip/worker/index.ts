import { createClient } from "@supabase/supabase-js";
import OpenAI from "openai";
import fs from "fs/promises";
import path from "path";
import os from "os";
import { execFile } from "child_process";
import { promisify } from "util";

const exec = promisify(execFile);
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

async function ffmpeg(args: string[]) {
  return exec("ffmpeg", args);
}

async function transcribe(localFile: string) {
  const result = await openai.audio.transcriptions.create({
    file: await OpenAI.toFile(await fs.readFile(localFile), path.basename(localFile)),
    model: "gpt-4o-mini-transcribe",
    response_format: "verbose_json",
    timestamp_granularities: ["segment"]
  } as any);
  return result;
}

async function scoreSegments(transcript: any) {
  const segments = transcript.segments || [];
  const prompt = `You are an expert short-form video editor.
Pick up to 5 segments from the transcript that can work as standalone social clips.
Prefer strong hooks, surprising claims, emotional moments, useful insights, conflict, jokes, or clear story beats.
Return JSON only: {"clips":[{"start":number,"end":number,"title":string,"hook":string,"caption":string,"reason":string}]}.
Each clip should be 20-75 seconds where possible.
Transcript segments:
${JSON.stringify(segments)}`;

  const r = await openai.chat.completions.create({
    model: "gpt-5-mini",
    response_format: { type: "json_object" },
    messages: [{ role: "user", content: prompt }]
  });
  return JSON.parse(r.choices[0].message.content || '{"clips":[]}');
}

async function renderClip(source: string, output: string, start: number, end: number) {
  const duration = Math.max(1, end - start);
  await ffmpeg([
    "-y", "-ss", String(start), "-i", source, "-t", String(duration),
    "-vf", "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2",
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
    "-c:a", "aac", "-movflags", "+faststart", output
  ]);
}

async function processJob(job: any) {
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(), "clipforge-"));
  try {
    await supabase.from("jobs").update({ status: "processing" }).eq("id", job.id);
    const { data, error } = await supabase.storage.from("videos").download(job.source_path);
    if (error || !data) throw error || new Error("Source download failed");

    const source = path.join(tmp, "source.mp4");
    await fs.writeFile(source, Buffer.from(await data.arrayBuffer()));

    const transcript = await transcribe(source);
    await supabase.from("jobs").update({ transcript }).eq("id", job.id);

    const suggestions = await scoreSegments(transcript);
    await supabase.from("jobs").update({ suggestions }).eq("id", job.id);

    const outputPaths: string[] = [];
    for (let i = 0; i < suggestions.clips.length; i++) {
      const c = suggestions.clips[i];
      const out = path.join(tmp, `clip-${i + 1}.mp4`);
      await renderClip(source, out, c.start, c.end);
      const storagePath = `${job.id}/clip-${i + 1}.mp4`;
      const buf = await fs.readFile(out);
      const up = await supabase.storage.from("videos").upload(storagePath, buf, {
        contentType: "video/mp4", upsert: true
      });
      if (up.error) throw up.error;
      outputPaths.push(storagePath);
    }

    await supabase.from("jobs").update({
      status: "complete",
      output_paths: outputPaths
    }).eq("id", job.id);
  } catch (e: any) {
    await supabase.from("jobs").update({ status: "failed", error: e.message }).eq("id", job.id);
    console.error(e);
  } finally {
    await fs.rm(tmp, { recursive: true, force: true });
  }
}

async function loop() {
  console.log("ClipForge worker running");
  while (true) {
    const { data: jobs } = await supabase
      .from("jobs")
      .select("*")
      .eq("status", "queued")
      .order("created_at", { ascending: true })
      .limit(1);

    if (jobs?.[0]) await processJob(jobs[0]);
    else await new Promise(r => setTimeout(r, 3000));
  }
}

loop().catch(console.error);